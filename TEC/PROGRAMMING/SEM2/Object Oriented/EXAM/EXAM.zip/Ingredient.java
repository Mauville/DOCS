class Ingredient {
    String name;

    public double getWeight() {
        return weight;
    }

    double weight;

    public int getCalories() {
        return calories;
    }

    int calories;

}