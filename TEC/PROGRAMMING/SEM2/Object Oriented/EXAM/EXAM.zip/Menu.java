public class Menu {
    String name;
    boolean breakfast, lunch, dinner;
    ArrayList<Dish> dishes = new ArrayList<Dish>();
}