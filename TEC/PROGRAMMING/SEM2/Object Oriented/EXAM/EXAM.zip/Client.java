import java.util.ArrayList;

public class Client {
    String name, email;
    ArrayList<Dish> dishes = new ArrayList<Dish>();
    }
}