public class Vehicle{
    String model, color;
    Report rep;

    public static boolean PassedTest(){
        if (rep.workingAP == true && TTR60mph < 5 && maxSpeed > 200)
            return true
        else
            return false
    }
}
