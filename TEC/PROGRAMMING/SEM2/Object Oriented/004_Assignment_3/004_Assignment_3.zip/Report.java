public class Report{

    boolean autopilot, workingAP;
    double TTR60mph, maxSpeed;

}
