public class main{
    public static void main(String[] args){
        Vehicle car1 = new Vehicle();
        System.out.println(car1.PassedTest());
        Vehicle car2 = new Vehicle();
        System.out.println(car2.PassedTest());

    }
}
