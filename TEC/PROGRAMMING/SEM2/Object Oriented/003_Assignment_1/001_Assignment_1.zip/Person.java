import java.util.Date;

public class Person{
            String name, surname, BankName;
            int age;
            long CLABE
}
