public class Loan {

        Person person;
        Bicycle bike;
        Date LoanDate, ReturnDate, LoanTime, ReturnTime;

}
