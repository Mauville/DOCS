import java.util.Date;

public class Bicycle{
    String brand;
    long regnum, serial;
    
}
