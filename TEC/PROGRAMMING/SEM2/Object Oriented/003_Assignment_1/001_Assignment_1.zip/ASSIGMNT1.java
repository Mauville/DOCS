import java.util.Date;

public class ASSIGMENT1{

    public static void main(String [] args){
        Person person = new Person();
        Loan loan = new Loan();
        Bicycle bike = new Bicycle();
    }
}
