public class Student {
    String name;
    int age;

    public void Report(boolean name) {
        if (name)
            System.out.println(this.name);
    }

    public void Report(boolean name, boolean age) {
        if (name)
            System.out.println(this.name);
        if (age)
            System.out.println(this.age);
    }

    public void Introduction() {
        System.out.println("Hello, my name is " + this.name + " and I am " + this.age);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

}
