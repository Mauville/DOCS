public class MAIN{

    public static void main(String [] args){
    Student mike = new Student();
    mike.setName("Mike");
    mike.setAge(19);
    mike.Report(true);
    mike.Report(true, true);

    mike.Introduction();

    Student Roland = new UNAM();
    Roland.Introduction();

    Student Froush = new Tec();
    Froush.Introduction();
    

    }
}

    
