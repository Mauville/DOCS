public class UNAM extends Student{
    public void Introduction() {
        super.name = "Mario";
        super.age = 24;
        System.out.println("Hola, mi nombre es " + super.name + " y tengo " + super.age + "anos");

    }
}
