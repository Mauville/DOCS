public class Tec extends Student {
    public void Introduction() {
        super.name = "Kevin";
        super.age = 20;
        System.out.println("Bonjour, je suis " + super.name + " j'ai " + super.age + "ans");
    }
}
