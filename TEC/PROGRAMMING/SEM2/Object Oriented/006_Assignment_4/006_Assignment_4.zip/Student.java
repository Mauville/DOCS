public class Student{
    int ID, age;
    String major;
    
    public Student(int id, int age, String Major){
        this.ID = id;
        this.major = Major;
        this.age = age;
    }
    public int getAge(){
        return this.age ;
    }
}
