public class main{
    public static void main(String [] args){
    Classroom clsroom = new Classroom();
    Student s1 = new Student(1, 18, "ITC");
    Student s2 = new Student(2, 20, "ITI");
    Student s3 = new Student(2, 16, "ITS");
    clsroom.addStudent(s1);
    clsroom.addStudent(s2);
    clsroom.addStudent(s3);

    }
}
