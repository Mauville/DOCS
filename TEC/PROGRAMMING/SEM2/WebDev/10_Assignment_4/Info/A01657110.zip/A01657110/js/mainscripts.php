<script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/jquery-1.9.1.min.js"><\/script>')</script>
<script src="<?php echo $homedir; ?>js/owl.carousel.min.js"></script>
<script src="<?php echo $homedir; ?>js/skrollr.js"></script>
<script src="<?php echo $homedir; ?>js/jquery.fancybox.pack.js"></script>
<script src="<?php echo $homedir; ?>js/_main.js"></script>